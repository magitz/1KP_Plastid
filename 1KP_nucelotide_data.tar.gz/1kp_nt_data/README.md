# 1KP Nucleotide data

Note that these data were not directly used in the Gitzendanner et al 2018 paper. 

Check the alignment and reading frame prior to use.

